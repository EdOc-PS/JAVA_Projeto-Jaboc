## Projeto-Jaboc ☕
🥤 Desenvolvimento de um projeto para a disciplina de POO, com foco na criação e operação de uma cafeteria.
<br>
👇 Baixe o executável e confira o projeto: [Download](https://raw.githubusercontent.com/EdOc-PS/Projeto-Jaboc/main/JabocCafeteria/dist/JabocCafeteria.jar)
<br>
🔑 Senha para a acessar a gerência: 123
<br><br>
**Usados no Projeto:**

- 📰 Diagrama UML: https://lucid.app/lucidchart/88644fbf-901c-4a58-b7b6-c9dddb4a31f1/edit?view_items=PxYDyldzbS1C&invitationId=inv_51db1cf9-0574-48df-8e9e-ecdc0350e321
- 🎨 Paleta de cores usadas: https://colorhunt.co/palette/8d7b68a4907cc8b6a6f1dec9
- 👩‍🍳 Icones: https://www.flaticon.com/br/icon-fonts-mas-baixados?weight=bold&type=uicon

  <samp> Feito por <b><a href="https://github.com/EdOc-PS">Eduardo Octávio</a></b> e <b><a href="https://github.com/GuilhermeVRF">Guilherme Victor</a></b> </samp>
